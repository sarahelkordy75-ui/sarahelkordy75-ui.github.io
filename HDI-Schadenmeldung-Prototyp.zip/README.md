# HDI Schadenmeldung – Prototyp

Öffne `index.html` lokal im Browser oder lade die Datei auf einen statischen Webhost.

Wichtig: Dies ist ein UX-/Frontend-Prototyp. Es findet keine echte Übertragung von Schadendaten an HDI statt und es werden keine echten HDI-Services angesprochen.
